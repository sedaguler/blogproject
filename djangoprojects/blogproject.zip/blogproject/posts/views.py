from django.shortcuts import render
from .models import BlogPost
from .models import BlogTopic
from django.db.models import Count


def topic_list(request):
    all_topics = BlogTopic.objects.filter(pk__in=BlogPost.objects.values('topic').annotate(count=Count('topic')).values('topic')).annotate(tcount=Count('title')).values('title')
    print(all_topics)
    return render(request, 'posts/topic_list.html', {'listoftopics':all_topics})

def single_topic_list(request, title):
    single_topic = BlogPost.objects.filter(topic = BlogTopic.objects.get(title__contains=title))
    return render(request, 'posts/single_topic.html', {'singletopic':single_topic})