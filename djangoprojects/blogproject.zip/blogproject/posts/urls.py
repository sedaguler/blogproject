from django.conf.urls import url
from posts import views

app_name = 'posts'

urlpatterns = [
    url(r'^$', views.topic_list, name='topic_list'),
    url(r'^(?P<title>[\w|\W]+)/$', views.single_topic_list, name='single_topic_list'),
]
